# global
this folder has cheats that work outside of games

# Paused in debugger
if you run one of the codes and get this: ![image](https://user-images.githubusercontent.com/73669084/133943133-af7cc9b8-75ab-496c-a17e-5851b6d7ff63.png) don't worry all you have to do is go to the sources tab: ![image](https://user-images.githubusercontent.com/73669084/133943102-701b0737-b0ca-4ccd-b533-e782c7767447.png) and click this: ![image](https://user-images.githubusercontent.com/73669084/133943169-2897f143-258f-49d8-81e3-181ffe857c8e.png) top right, lastly click this: ![image](https://user-images.githubusercontent.com/73669084/133943122-bc762f73-8522-435a-abb8-905233c95ebe.png) to get out of debugger


# addTokens.js
**note:** blooket changed the url to get tokens, so this script adds tokens and max xp to your account. You can get 300 xp a day.


Open console (ctrl + shift + j) and pase the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/addTokens.js").then((res) => res.text().then((t) => eval(t)))
```

# getEveryAnswerCorrect.js
THIS CHEAT IS OVERPOWERED

even if you pick the wrong answer it will say its correct, its literally crazy...

note: **This doesn't work for classic game mode.**

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/getEveryAnswerCorrect.js").then((res) => res.text().then((t) => eval(t)))
```

# bypassRandomName.js 
This cheat just lets you have a custom name when random name is active;

note: **Box names are case sensitive**

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/bypassRandomName.js").then((res) => res.text().then((t) => eval(t)))
```
# spamOpenBoxes.js
When it asks you to open a box always include the whole box name.

for example: Aquatic Box

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/spamOpenBoxes.js").then((res) => res.text().then((t) => eval(t)))
```

# getAllBlooksInGame.js
This cheat gives you all blooks only in game when you are /play/lobby page.

video: 

https://user-images.githubusercontent.com/73669084/135732015-33bb6eed-772f-45f8-82ed-b079fbdead29.mp4

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/getAllBlooksInGame.js").then((res) => res.text().then((t) => eval(t)))
```

# floodGames.js
You can't add more than 100 bots.

tutorial: 
https://user-images.githubusercontent.com/73669084/135941885-6ed837b9-197c-4e92-88fb-43abadfd6625.mp4


Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/floodGames.js").then((res) => res.text().then((t) => eval(t)))
```
