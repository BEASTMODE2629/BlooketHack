# How to run python
- download python at: https://www.python.org/downloads/

- make a file (example: myfile.py) and paste my script from https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/py/24hr-token-adder.py into the `.py` file you created

- then do `python 24hr-token-adder.py` in cmd
