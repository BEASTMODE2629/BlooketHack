This cheat only works in tower defense game mode!

# Paused in debugger
if you run one of the codes and get this: ![image](https://user-images.githubusercontent.com/73669084/133943133-af7cc9b8-75ab-496c-a17e-5851b6d7ff63.png) don't worry all you have to do is go to the sources tab: ![image](https://user-images.githubusercontent.com/73669084/133943102-701b0737-b0ca-4ccd-b533-e782c7767447.png) and click this: ![image](https://user-images.githubusercontent.com/73669084/133943169-2897f143-258f-49d8-81e3-181ffe857c8e.png) top right, lastly click this: ![image](https://user-images.githubusercontent.com/73669084/133943122-bc762f73-8522-435a-abb8-905233c95ebe.png) to get out of debugger


# getCash.js
Open console (ctrl + shift + j) and pase the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-cheat/main/tower-defense/getCash.js").then((res) => res.text().then((t) => eval(t)))
```
# changeGameRound.js
watch the video here lol: https://streamable.com/9oclww
Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/changeGameRound.js").then((res) => res.text().then((t) => eval(t)))
```
# allFree.js
Makes all the towers free, but you still need the base value to buy one
Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/allFree.js").then((res) => res.text().then((t) => eval(t)))
```
# removeEnemies.js
Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/removeEnemies.js").then((res) => res.text().then((t) => eval(t)))
```
# removeDucks.js
Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/removeDucks.js").then((res) => res.text().then((t) => eval(t)))
```
# removeObsticles.js
Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/removeObsticles.js").then((res) => res.text().then((t) => eval(t)))
```
# sellForTrueValue.js
Makes towers sell for the price you bought them
Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/sellForTrueValue.js").then((res) => res.text().then((t) => eval(t)))
```
